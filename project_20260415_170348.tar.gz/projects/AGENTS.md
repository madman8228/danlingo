## 项目概述
- **名称**: 7步词汇扩展工作流（优化版）
- **功能**: 复杂的7步词汇处理工作流，从初始单词列表开始，逐步扩展知识并生成多个文档。已优化模型调用次数，避免指数级增长和减少批量处理

### 节点清单
| 节点名 | 文件位置 | 类型 | 功能描述 | 分支逻辑 | 配置文件 | 优化说明 |
|-------|---------|------|---------|---------|---------|---------|
| generate_initial_knowledge | `nodes/generate_initial_knowledge_node.py` | agent | 为初始单词列表生成知识块，写入word_knowledge.md | - | - | - |
| append_synonyms_antonyms | `nodes/append_synonyms_antonyms_node.py` | task | 遍历synonyms和antonyms中的单词，追加到word_knowledge.md（优化版） | - | - | 限制数量避免指数级增长，暂不生成知识 |
| process_phrases | `nodes/process_phrases_node.py` | agent | 遍历phrases，生成phrase_knowledge.md（优化版） | - | - | 批量处理，3个一组 |
| process_collocations | `nodes/process_remaining_nodes.py` | agent | 遍历collocations，生成collocations_knowledge.md（优化版） | - | - | 批量处理，5个一组 |
| process_sentence_patterns | `nodes/process_remaining_nodes.py` | agent | 遍历sentencePatterns，生成sentencePatterns_knowledge.md（优化版） | - | - | 批量处理，5个一组 |
| process_spoken_expressions | `nodes/process_remaining_nodes.py` | agent | 遍历spokenExpressions，生成spokenExpressions_knowledge.md（优化版） | - | - | 批量处理，5个一组 |
| process_idioms | `nodes/process_remaining_nodes.py` | agent | 遍历idioms，生成idioms_knowledge.md（优化版） | - | - | 批量处理，5个一组 |

**类型说明**: task(task节点) / agent(大模型) / condition(条件分支) / looparray(列表循环) / loopcond(条件循环)

## 子图清单
无

## 技能使用
- 节点 `generate_initial_knowledge` 使用技能：大语言模型 (doubao-seed-2-0-pro-260215)
- 节点 `process_phrases` 使用技能：大语言模型 (doubao-seed-2-0-pro-260215)
- 节点 `process_collocations` 使用技能：大语言模型 (doubao-seed-2-0-pro-260215)
- 节点 `process_sentence_patterns` 使用技能：大语言模型 (doubao-seed-2-0-pro-260215)
- 节点 `process_spoken_expressions` 使用技能：大语言模型 (doubao-seed-2-0-pro-260215)
- 节点 `process_idioms` 使用技能：大语言模型 (doubao-seed-2-0-pro-260215)

## 工作流说明
### 7步工作流流程：
1. **输入**: 单词列表（如 ["take", "stop", "view"]）
2. **流程**:
   - **步骤1**: 为每个初始单词生成完整的词汇扩展知识，合并到 word_knowledge.md，每个单词用 ## word 作为知识块
   - **步骤2**: 遍历 word_knowledge.md 中所有单词的 synonyms 和 antonyms 中的所有单词，把它们追加到 word_knowledge.md（已优化：限制数量避免指数级增长）
   - **步骤3**: 遍历 word_knowledge 中的所有知识块的 phrases，依次写到 phrase_knowledge.md 中，每个 phrase 以 ## phrases 开头，需要填写 collocations、sentencePatterns、spokenExpressions、idioms、example（已优化：批量处理，3个一组）
   - **步骤4**: 遍历 word_knowledge 中的所有知识块的 collocations，每个 collocations 以 ## collocations 开头，需要填写至少2个 example（已优化：批量处理，5个一组）
   - **步骤5**: 遍历 word_knowledge 中的所有知识块的 sentencePatterns，每个 sentencePatterns 以 ## sentencePatterns 开头，需要填写至少2个 example（已优化：批量处理，5个一组）
   - **步骤6**: 遍历 word_knowledge 中的所有知识块的 spokenExpressions，每个 spokenExpressions 以 ## spokenExpressions 开头，需要填写至少2个 example（已优化：批量处理，5个一组）
   - **步骤7**: 遍历 word_knowledge 中的所有知识块的 idioms，每个 idioms 以 ## idioms 开头，需要填写至少2个 example（已优化：批量处理，5个一组）

3. **输出**:
   - word_knowledge.md: 包含所有单词的完整知识
   - phrase_knowledge.md: 包含所有短语的知识
   - collocations_knowledge.md: 包含所有搭配的知识
   - sentencePatterns_knowledge.md: 包含所有句型的知识
   - spokenExpressions_knowledge.md: 包含所有口语表达的知识
   - idioms_knowledge.md: 包含所有习语的知识

## 模型调用优化说明

### 优化前的问题
1. **步骤2指数级增长**: 每个单词的 synonyms 又会有自己的 synonyms，无限递归，导致调用次数爆炸
2. **步骤3-7单次调用**: 每个短语/搭配/句型等都单独调用一次LLM，效率低下

### 优化方案

#### 优化1：步骤2 - 避免指数级增长
- **优化前**: 为每个 synonyms 和 antonyms 的单词调用LLM生成完整知识
- **优化后**:
  - 每个单词最多取3个 synonyms，2个 antonyms
  - 总共最多添加10个新单词
  - 仅记录相关单词，暂不生成完整知识
- **效果**: 避免了指数级增长，LLM调用次数稳定

#### 优化2：步骤3-7 - 批量处理减少调用次数
- **优化前**: 每个项目单独调用一次LLM
- **优化后**:
  - 短语：3个一组批量处理
  - 搭配/句型/口语/习语：5个一组批量处理
  - 一次性LLM调用生成多个项目的知识
- **效果**: LLM调用次数大幅减少（例如10个短语只需4次调用，而非10次）

### 优化效果预估
- **初始单词数**: 3个
- **优化前LLM调用**: 约20-30次（包含步骤2的递归）
- **优化后LLM调用**: 约6-8次（步骤1-7，批量处理）
- **优化率**: 约70%的LLM调用次数减少

## 注意事项
- 本工作流非常复杂，包含7个步骤和多次大模型调用
- 已优化模型调用次数，但仍建议从小规模单词列表开始测试
- 每个步骤都需要大量时间处理
- 所有节点都使用真实的LLM调用，无Mock数据
