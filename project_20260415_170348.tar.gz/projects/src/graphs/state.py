from typing import Literal, Optional, List
from pydantic import BaseModel, Field
from utils.file.file import File


class GlobalState(BaseModel):
    """全局状态定义"""
    word_list: List[str] = Field(..., description="初始单词列表")
    word_knowledge_path: str = Field(default="", description="word_knowledge.md 文件路径")
    phrase_knowledge_path: str = Field(default="", description="phrase_knowledge.md 文件路径")
    collocations_knowledge_path: str = Field(default="", description="collocations_knowledge.md 文件路径")
    sentencePatterns_knowledge_path: str = Field(default="", description="sentencePatterns_knowledge.md 文件路径")
    spokenExpressions_knowledge_path: str = Field(default="", description="spokenExpressions_knowledge.md 文件路径")
    idioms_knowledge_path: str = Field(default="", description="idioms_knowledge.md 文件路径")
    success: bool = Field(default=False, description="处理是否成功")
    error_message: str = Field(default="", description="错误信息")


class GraphInput(BaseModel):
    """工作流的输入"""
    word_list: List[str] = Field(..., description="要处理的单词列表，例如 [\"take\", \"stop\", \"view\"]")


class GraphOutput(BaseModel):
    """工作流的输出"""
    success: bool = Field(..., description="处理是否成功")
    word_knowledge_path: str = Field(..., description="word_knowledge.md 文件路径")
    phrase_knowledge_path: str = Field(default="", description="phrase_knowledge.md 文件路径")
    collocations_knowledge_path: str = Field(default="", description="collocations_knowledge.md 文件路径")
    sentencePatterns_knowledge_path: str = Field(default="", description="sentencePatterns_knowledge.md 文件路径")
    spokenExpressions_knowledge_path: str = Field(default="", description="spokenExpressions_knowledge.md 文件路径")
    idioms_knowledge_path: str = Field(default="", description="idioms_knowledge.md 文件路径")
    message: str = Field(default="", description="处理结果消息")


class GenerateInitialKnowledgeInput(BaseModel):
    """生成初始知识节点的输入"""
    word_list: List[str] = Field(..., description="初始单词列表")


class GenerateInitialKnowledgeOutput(BaseModel):
    """生成初始知识节点的输出"""
    word_knowledge_path: str = Field(..., description="word_knowledge.md 文件路径")
    success: bool = Field(..., description="是否成功")


class AppendSynonymsAntonymsInput(BaseModel):
    """追加同义词反义词节点的输入"""
    word_knowledge_path: str = Field(..., description="word_knowledge.md 文件路径")


class AppendSynonymsAntonymsOutput(BaseModel):
    """追加同义词反义词节点的输出"""
    word_knowledge_path: str = Field(..., description="更新后的 word_knowledge.md 文件路径")
    success: bool = Field(..., description="是否成功")


class ProcessPhrasesInput(BaseModel):
    """处理短语节点的输入"""
    word_knowledge_path: str = Field(..., description="word_knowledge.md 文件路径")


class ProcessPhrasesOutput(BaseModel):
    """处理短语节点的输出"""
    phrase_knowledge_path: str = Field(..., description="phrase_knowledge.md 文件路径")
    success: bool = Field(..., description="是否成功")


class ProcessCollocationsInput(BaseModel):
    """处理搭配节点的输入"""
    word_knowledge_path: str = Field(..., description="word_knowledge.md 文件路径")


class ProcessCollocationsOutput(BaseModel):
    """处理搭配节点的输出"""
    collocations_knowledge_path: str = Field(..., description="collocations_knowledge.md 文件路径")
    success: bool = Field(..., description="是否成功")


class ProcessSentencePatternsInput(BaseModel):
    """处理句型节点的输入"""
    word_knowledge_path: str = Field(..., description="word_knowledge.md 文件路径")


class ProcessSentencePatternsOutput(BaseModel):
    """处理句型节点的输出"""
    sentencePatterns_knowledge_path: str = Field(..., description="sentencePatterns_knowledge.md 文件路径")
    success: bool = Field(..., description="是否成功")


class ProcessSpokenExpressionsInput(BaseModel):
    """处理口语表达节点的输入"""
    word_knowledge_path: str = Field(..., description="word_knowledge.md 文件路径")


class ProcessSpokenExpressionsOutput(BaseModel):
    """处理口语表达节点的输出"""
    spokenExpressions_knowledge_path: str = Field(..., description="spokenExpressions_knowledge.md 文件路径")
    success: bool = Field(..., description="是否成功")


class ProcessIdiomsInput(BaseModel):
    """处理习语节点的输入"""
    word_knowledge_path: str = Field(..., description="word_knowledge.md 文件路径")


class ProcessIdiomsOutput(BaseModel):
    """处理习语节点的输出"""
    idioms_knowledge_path: str = Field(..., description="idioms_knowledge.md 文件路径")
    success: bool = Field(..., description="是否成功")
