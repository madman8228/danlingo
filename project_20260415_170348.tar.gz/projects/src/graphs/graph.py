from langgraph.graph import StateGraph, END
from graphs.state import (
    GlobalState,
    GraphInput,
    GraphOutput
)
from graphs.nodes.generate_initial_knowledge_node import generate_initial_knowledge_node
from graphs.nodes.append_synonyms_antonyms_node import append_synonyms_antonyms_node
from graphs.nodes.process_phrases_node import process_phrases_node
from graphs.nodes.process_remaining_nodes import (
    process_collocations_node,
    process_sentence_patterns_node,
    process_spoken_expressions_node,
    process_idioms_node
)


# 创建状态图
builder = StateGraph(GlobalState, input_schema=GraphInput, output_schema=GraphOutput)

# 添加节点
builder.add_node("generate_initial_knowledge", generate_initial_knowledge_node)
builder.add_node("append_synonyms_antonyms", append_synonyms_antonyms_node)
builder.add_node("process_phrases", process_phrases_node)
builder.add_node("process_collocations", process_collocations_node)
builder.add_node("process_sentence_patterns", process_sentence_patterns_node)
builder.add_node("process_spoken_expressions", process_spoken_expressions_node)
builder.add_node("process_idioms", process_idioms_node)

# 设置入口点
builder.set_entry_point("generate_initial_knowledge")

# 添加边
builder.add_edge("generate_initial_knowledge", "append_synonyms_antonyms")
builder.add_edge("append_synonyms_antonyms", "process_phrases")
builder.add_edge("process_phrases", "process_collocations")
builder.add_edge("process_collocations", "process_sentence_patterns")
builder.add_edge("process_sentence_patterns", "process_spoken_expressions")
builder.add_edge("process_spoken_expressions", "process_idioms")
builder.add_edge("process_idioms", END)

# 编译图
main_graph = builder.compile()
